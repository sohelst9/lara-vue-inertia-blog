<template>
    <div>
        <h1>Terms and Conditions</h1>
        <p>Please read these terms and conditions carefully before using our service.</p>
    </div>
</template>



<style scoped>
h1 {
    color: #333;
}
p {
    font-size: 16px;
}
</style>