<template>
    <div>
        <h1>Privacy Policy</h1>
        <p>This is the privacy policy page.</p>
    </div>
</template>

<style scoped>
h1 {
    color: #333;
}

p {
    font-size: 16px;
}
</style>